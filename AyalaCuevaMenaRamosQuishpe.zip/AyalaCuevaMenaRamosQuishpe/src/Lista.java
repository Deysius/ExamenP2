import javax.swing.*;

public class Lista {
    public Nodo inicio;
    public Nodo fin;
    int contador;

    public Lista() {
        this.inicio = null;
        this.fin = null;
        this.contador = 0;
    }
    public SpiderverseHero buscarCodigo(int codigo) {
        Nodo actual = inicio;
        while (actual != null) {
            if (actual.heroe.codigo == codigo) {
                return actual.heroe;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void agregarNodo(Nodo nodo) {
        if (inicio == null) {
            inicio = nodo;
            fin = nodo;
        } else {
            fin.siguiente = nodo;
            fin = nodo;
        }
        contador++;
    }

    public void ordenarPorExperiencia() {
        if (inicio == null || inicio.siguiente == null) {
            return;
        }

        boolean cambiado;
        do {
            Nodo actual = inicio;
            Nodo anterior = null;
            Nodo siguiente = inicio.siguiente;
            cambiado = false;

            while (siguiente != null) {
                if (actual.heroe.experiencia > siguiente.heroe.experiencia) {
                    if (anterior == null) {
                        inicio = siguiente;
                    } else {
                        anterior.siguiente = siguiente;
                    }

                    actual.siguiente = siguiente.siguiente;
                    siguiente.siguiente = actual;

                    cambiado = true;
                    anterior = siguiente;
                    siguiente = actual.siguiente;
                } else {
                    anterior = actual;
                    actual = siguiente;
                    siguiente = siguiente.siguiente;
                }
            }
        } while (cambiado);
    }



    public Lista filtrarYOrdenarPorPoder(String poder) {
        Lista nuevaLista = new Lista();
        Nodo actual = inicio;

        while (actual != null) {
            if (!actual.heroe.poderes.equals(poder)) {
                Nodo nuevoNodo = new Nodo();
                nuevoNodo.heroe = actual.heroe;
                nuevaLista.agregarNodo(nuevoNodo);
            }
            actual = actual.siguiente;
        }

        nuevaLista.ordenarPorExperiencia();
        return nuevaLista;
    }


    public void ordenar() {
        ordenarPorExperiencia();
    }
}
