import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SpiderverseHeroGIU {

    Lista heroes =new Lista();


    private JPanel pGeneral;
    private JTabbedPane tabbedPane1;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JComboBox poderBox;
    private JComboBox universoBox;
    private JComboBox expBox;
    private JTextField txtBusqueda;
    private JButton registrarButton;
    private JTextArea salidaBusqueda;
    private JButton buscarButton;
    private JComboBox comboFiltrado;
    private JButton filtrarButton;
    private JTable tablaFiltrado;
    private JTextArea salidaMostrar;
    private JButton mostrarHeroesActivosButton;

    public SpiderverseHeroGIU() {


        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputCodigo = txtCodigo.getText();
                String inputNombre = txtNombre.getText();
                try {
                    SpiderverseHero heroeNuevo = new SpiderverseHero();
                    heroeNuevo.nombre = inputNombre;
                    heroeNuevo.codigo = Integer.parseInt(inputCodigo);

                    if (existeCodigo(heroes.inicio, heroeNuevo.codigo)) {
                        JOptionPane.showMessageDialog(null, "El código ingresado ya existe. Intente con otro.");
                        return;
                    }

                    switch (poderBox.getSelectedIndex()) {
                        case 1:
                            heroeNuevo.poderes = "Sentido Aracnido";
                            break;
                        case 2:
                            heroeNuevo.poderes = "Trepa Muros";
                            break;
                        case 3:
                            heroeNuevo.poderes = "Fuerza Sobrehumana";
                            break;
                        case 4:
                            heroeNuevo.poderes = "Agilidad mejorada";
                            break;
                        case 5:
                            heroeNuevo.poderes = "Tejido de Telaraña";
                            break;
                        default:
                            return;
                    }

                    switch (universoBox.getSelectedIndex()) {
                        case 1:
                            heroeNuevo.universo = "Tierra-616";
                            break;
                        case 2:
                            heroeNuevo.universo = "Tierra-1610";
                            break;
                        case 3:
                            heroeNuevo.universo = "Tierra-12041";
                            break;
                        case 4:
                            heroeNuevo.universo = "Tierra-90214";
                            break;
                        case 5:
                            heroeNuevo.universo = "Tierra-138";
                            break;
                        default:
                            return;
                    }

                    switch (expBox.getSelectedIndex()) {
                        case 1:
                            heroeNuevo.experiencia = 1;
                            break;
                        case 2:
                            heroeNuevo.experiencia = 2;
                            break;
                        case 3:
                            heroeNuevo.experiencia = 3;
                            break;
                        case 4:
                            heroeNuevo.experiencia = 4;
                            break;
                        case 5:
                            heroeNuevo.experiencia = 5;
                            break;
                        default:
                            return;
                    }

                    Nodo nodo = new Nodo();
                    nodo.heroe = heroeNuevo;
                    heroes.agregarNodo(nodo);
                    heroes.ordenar();
                    burbuja();
                    JOptionPane.showMessageDialog(null, "Héroe registrado correctamente!");
                    txtCodigo.setText("");
                    txtNombre.setText("");
                    poderBox.setSelectedIndex(0);
                    universoBox.setSelectedIndex(0);
                    expBox.setSelectedIndex(0);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un número correcto para el código.");
                }
            }
        });


        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputBusqueda = txtBusqueda.getText();
                try {
                    int codigoBusqueda = Integer.parseInt(inputBusqueda);
                    SpiderverseHero heroeEncontrado = heroes.buscarCodigo(codigoBusqueda);

                    if (heroeEncontrado != null) {
                        salidaBusqueda.setText("Héroe encontrado:\n" +
                                "Código: " + heroeEncontrado.codigo + "\n" +
                                "Nombre: " + heroeEncontrado.nombre + "\n" +
                                "Poderes: " + heroeEncontrado.poderes + "\n" +
                                "Universo: " + heroeEncontrado.universo + "\n" +
                                "Experiencia: " + heroeEncontrado.experiencia);
                    } else {
                        salidaBusqueda.setText("No se encontró al héroe con el código: " + codigoBusqueda);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un número correcto para el código.");
                }
            }
        });

        filtrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String poderSeleccionado = (String) poderBox.getSelectedItem();

                if (poderSeleccionado != null && !poderSeleccionado.isEmpty()) {
                    Lista filtradaLista = heroes.filtrarYOrdenarPorPoder(poderSeleccionado);

                    String[] columnas = {"Código", "Nombre", "Poder", "Universo", "Experiencia"};
                    Object[][] datos = new Object[filtradaLista.contador][5];
                    Nodo actual = filtradaLista.inicio;
                    int fila = 0;

                    while (actual != null) {
                        datos[fila][0] = actual.heroe.codigo;
                        datos[fila][1] = actual.heroe.nombre;
                        datos[fila][2] = actual.heroe.poderes;
                        datos[fila][3] = actual.heroe.universo;
                        datos[fila][4] = actual.heroe.experiencia;
                        fila++;
                        actual = actual.siguiente;
                    }

                    tablaFiltrado.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione un poder válido para filtrar.");
                }
            }
        });

        mostrarHeroesActivosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] universos = {"Tierra-616", "Tierra-1610", "Tierra-12041", "Tierra-90214", "Tierra-138"};
                StringBuilder resultados = new StringBuilder();
                for (String universo : universos) {
                    int cantidad = contarHeroesPorUniverso(heroes.inicio, universo);
                    resultados.append("Universo ").append(universo).append(": ").append(cantidad).append(" héroes activos.\n");
                }
                salidaMostrar.setText(resultados.toString());
            }
        });
    }
    public int contarHeroesPorUniverso(Nodo nodoActual, String universo) {
        if (nodoActual == null) {
            return 0;
        }

        int contador = nodoActual.heroe.universo.equals(universo) ? 1 : 0;
        return contador + contarHeroesPorUniverso(nodoActual.siguiente, universo);
    }
    private boolean existeCodigo(Nodo nodoActual, int codigo) {
        if (nodoActual == null) {
            return false;
        }
        if (nodoActual.heroe.codigo == codigo) {
            return true;
        }
        return existeCodigo(nodoActual.siguiente, codigo);
    }


    public void burbuja(){
        Nodo nodoActual = heroes.inicio;

        for (int i = 0; i < heroes.contador; i++) {
            for (int j = 0; j < heroes.contador; j++) {
                if (nodoActual.heroe.experiencia > nodoActual.siguiente.heroe.experiencia){
                    Nodo cambio = nodoActual;
                    nodoActual.siguiente= nodoActual;
                    nodoActual.siguiente = cambio;
                }
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("SpiderverseHeroGIU");
        frame.setContentPane(new SpiderverseHeroGIU().pGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
