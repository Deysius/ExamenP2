public class Nodo {

    Nodo siguiente;
    SpiderverseHero heroe;

    public Nodo() {
    siguiente=null;
    heroe=null;
    }

}
