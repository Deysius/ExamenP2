public class SpiderverseHero {
    int codigo;
    String nombre;
    String poderes;
    String universo;
    int experiencia;

    public SpiderverseHero() {
        this.codigo = 0;
        this.nombre = null;
        this.poderes = null;
        this.universo = null;
        this.experiencia = 0;
    }
}
